package com.gl.sms.service;

public interface RegnService {

}
